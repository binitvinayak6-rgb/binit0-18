/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, useScroll, useTransform, AnimatePresence } from "motion/react";
import { 
  BrowserRouter as Router, 
  Routes, 
  Route, 
  Link, 
  useLocation,
  useNavigate
} from "react-router-dom";
import { 
  ArrowUpRight, 
  Instagram, 
  Twitter, 
  Youtube, 
  Facebook, 
  Globe, 
  ArrowRight,
  Mail,
  MapPin,
  Calendar,
  Upload,
  X,
  Plus,
  LogOut,
  Trash2,
  Loader2,
  Camera,
  Video,
  Film,
  Palette,
  Layout,
  Image,
  Share2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import React, { useRef, useState, useEffect } from "react";
import emailjs from "@emailjs/browser";
import { auth, db, storage } from "./firebase";
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  onAuthStateChanged,
  User 
} from "firebase/auth";
import { 
  collection, 
  addDoc, 
  query, 
  orderBy, 
  onSnapshot, 
  deleteDoc, 
  doc,
  serverTimestamp,
  Timestamp
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

interface Project {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  createdAt: Timestamp;
  userId: string;
}

const Navbar = () => {
  const location = useLocation();
  const isHomePage = location.pathname === "/";

  const scrollToSection = (id: string) => {
    if (isHomePage) {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  };

  return (
    <nav className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-6 py-4 bg-background/80 backdrop-blur-sm border-b border-border/50">
      <Link to="/" className="flex items-center gap-2">
        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
          <div className="w-4 h-4 bg-background rounded-full" />
        </div>
      </Link>
      <div className="hidden md:flex gap-8 text-sm font-medium uppercase tracking-widest">
        {isHomePage ? (
          <>
            <a href="#home" onClick={(e) => { e.preventDefault(); scrollToSection("home"); }} className="hover:text-accent transition-colors">Home</a>
            <a href="#about" onClick={(e) => { e.preventDefault(); scrollToSection("about"); }} className="hover:text-accent transition-colors">About</a>
            <Link to="/portfolio" className="hover:text-accent transition-colors">Portfolio</Link>
            <a href="#services" onClick={(e) => { e.preventDefault(); scrollToSection("services"); }} className="hover:text-accent transition-colors">Services</a>
            <a href="#contact" onClick={(e) => { e.preventDefault(); scrollToSection("contact"); }} className="hover:text-accent transition-colors">Contact</a>
          </>
        ) : (
          <>
            <Link to="/" className="hover:text-accent transition-colors">Home</Link>
            <Link to="/portfolio" className="text-accent transition-colors">Portfolio</Link>
          </>
        )}
      </div>
      <div className="flex items-center gap-4 text-xs font-medium text-muted-foreground">
        <span className="flex items-center gap-1">
          <Globe className="w-3 h-3 text-accent" />
          India
        </span>
      </div>
    </nav>
  );
};

const Hero = () => {
  return (
    <section id="home" className="pt-32 pb-20 px-6 max-w-7xl mx-auto min-h-screen flex flex-col justify-center">
      <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex flex-col gap-8"
        >
          <h1 className="text-huge font-bold tracking-tighter text-primary-black">
            Hi, I'm<br />Binit Vinayak
          </h1>
          <p className="max-w-2xl text-xl text-muted-foreground leading-relaxed">
            A student freelancer and graphic designer. I always strive to deliver high-quality work on time and look forward to collaborating with creative clients.
          </p>
          <div className="flex justify-center gap-12 pt-8">
            <div>
              <span className="text-4xl font-bold font-heading">2+</span>
              <p className="text-xs uppercase tracking-widest text-muted-foreground mt-1">
                Years of Experience
              </p>
            </div>
            <div>
              <span className="text-4xl font-bold font-heading">500+</span>
              <p className="text-xs uppercase tracking-widest text-muted-foreground mt-1">
                Projects Done
              </p>
            </div>
            <div>
              <span className="text-4xl font-bold font-heading">100+</span>
              <p className="text-xs uppercase tracking-widest text-muted-foreground mt-1">
                Clients
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const About = () => {
  return (
    <section id="about" className="bg-primary-black text-background py-32 overflow-hidden relative">
      <div className="absolute top-10 left-0 w-full opacity-20 pointer-events-none overflow-hidden">
        <div className="flex whitespace-nowrap text-[10vw] font-bold uppercase tracking-tighter leading-none select-none animate-marquee">
          {[...Array(10)].map((_, i) => (
            <span key={i} className="mr-10">about.</span>
          ))}
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="flex flex-col items-center text-center gap-12">
          <div className="relative w-80 h-80 md:w-[500px] md:h-[500px] flex items-center justify-center">
            {/* Petal Pattern */}
            <div className="absolute inset-0 flex items-center justify-center opacity-80">
              {[...Array(24)].map((_, i) => (
                <div 
                  key={i} 
                  className="petal-shape" 
                  style={{ 
                    transform: `translate(-50%, -100%) rotate(${i * 15}deg)`,
                    height: i % 2 === 0 ? '200px' : '180px',
                    opacity: 0.8 - (i % 3) * 0.2
                  }} 
                />
              ))}
            </div>
            
            <motion.div 
              whileInView={{ scale: [0.9, 1], opacity: [0, 1] }}
              transition={{ duration: 1 }}
              className="relative w-64 h-64 md:w-96 md:h-96 rounded-full overflow-hidden border-4 border-accent-gold/30 z-10"
            >
              <img 
                src="https://i.postimg.cc/ydfHMpsg/photo-6265061682669358904-y.jpg" 
                alt="About Subject" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </motion.div>
            
            {/* Crosshair markers */}
            <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-accent-gold/50" />
            <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-accent-gold/50" />
            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-accent-gold/50" />
            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-accent-gold/50" />
          </div>
          
          <div className="max-w-6xl w-full grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-8 border border-border/20 rounded-xl bg-white/5 backdrop-blur-sm text-left">
              <h3 className="text-2xl font-bold mb-3 text-accent-gold uppercase tracking-wider">Education</h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                A BBA student blending business strategy with creative design to deliver impactful visual solutions.
              </p>
            </div>
            <div className="p-8 border border-border/20 rounded-xl bg-white/5 backdrop-blur-sm text-left">
              <h3 className="text-2xl font-bold mb-3 text-accent-gold uppercase tracking-wider">Background</h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Student freelancer with 2 years of experience in graphic design. Specialized in YouTube thumbnails and social media content that drives engagement.
              </p>
            </div>
            <div className="p-8 border border-border/20 rounded-xl bg-white/5 backdrop-blur-sm text-left">
              <h3 className="text-2xl font-bold mb-3 text-accent-gold uppercase tracking-wider">Passion</h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Deeply passionate about creativity and consistency. I believe great design tells a story and converts viewers into loyal audiences.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Portfolio = () => {
  const navigate = useNavigate();
  const projects = [
    { id: 1, title: "", category: "", img: "https://i.postimg.cc/0js5cSwN/without-usa.png", size: "large" },
    { id: 2, title: "", category: "", img: "https://images.unsplash.com/photo-1493246507139-91e8bef99c02?auto=format&fit=crop&q=80&w=800", size: "small" },
    { id: 3, title: "", category: "", img: "https://images.unsplash.com/photo-1449156001437-3a1621dfbe28?auto=format&fit=crop&q=80&w=800", size: "medium" },
    { id: 4, title: "", category: "", img: "https://i.postimg.cc/BvPMCP3N/Chat-GPT-Image-Apr-13-2026-11-24-57-AM.png", size: "small" },
    { id: 6, title: "", category: "", img: "https://i.postimg.cc/vTfXfcJr/thumb-YT.png", size: "small" },
    { id: 5, title: "", category: "", img: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&q=80&w=800", size: "accent" },
  ];

  return (
    <section id="portfolio" className="py-32 px-6 max-w-7xl mx-auto relative">
      <div className="portfolio-overlay-text opacity-100">portfolio</div>
      
      <div className="flex flex-col gap-12 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {projects.map((project) => (
            <motion.div 
              key={project.id}
              whileHover={{ y: -10 }}
              className={`relative overflow-hidden group rounded-[3rem] ${
                project.size === 'large' ? 'md:col-span-1 md:row-span-2' : 
                project.size === 'accent' ? 'bg-accent-gold p-8' : ''
              }`}
            >
              {project.size !== 'accent' ? (
                <div className="aspect-square md:aspect-auto h-full w-full grayscale-to-color hover-zoom">
                  <img 
                    src={project.img} 
                    alt={project.title} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              ) : (
                <div className="h-full flex flex-col justify-center items-center text-center">
                  <ArrowUpRight className="w-12 h-12 mb-6" />
                  <Button 
                    variant="ghost" 
                    onClick={() => navigate('/portfolio')}
                    className="p-0 hover:bg-transparent flex items-center gap-2 font-bold uppercase tracking-widest text-xs"
                  >
                    View Full Gallery <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const PortfolioPage = () => {
  const projects = [
    { id: 1, title: "", category: "", img: "https://i.postimg.cc/0js5cSwN/without-usa.png" },
    { id: 4, title: "", category: "", img: "https://i.postimg.cc/BvPMCP3N/Chat-GPT-Image-Apr-13-2026-11-24-57-AM.png" },
    { id: 6, title: "", category: "", img: "https://i.postimg.cc/vTfXfcJr/thumb-YT.png" },
  ];

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="pt-32 pb-20 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col gap-12">
        <div className="max-w-xl">
          <h1 className="text-6xl font-bold tracking-tighter mb-4">Gallery</h1>
          <p className="text-muted-foreground text-lg">A comprehensive collection of my creative endeavors and visual explorations.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <motion.div 
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              whileHover={{ y: -10 }}
              className="relative overflow-hidden group rounded-[2rem] aspect-square bg-muted"
            >
              <img 
                src={project.img} 
                alt={project.title} 
                className="w-full h-full object-cover grayscale-to-color transition-all duration-700"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

const Services = () => {
  const services = [
    { 
      id: "01", 
      title: "Thumbnail Designing", 
      description: "Eye-catching, high-CTR thumbnails designed to grab attention and boost your video performance instantly.",
      icon: <Layout className="w-6 h-6" />
    },
    { 
      id: "02", 
      title: "Poster Making", 
      description: "Creative social media posts and professional poster designs that capture your brand's essence and engage your audience.",
      icon: <Image className="w-6 h-6" />
    },
    { 
      id: "03", 
      title: "Social Media Management", 
      description: "Complete management of your social presence, from content scheduling to community engagement and growth strategy.",
      icon: <Share2 className="w-6 h-6" />
    },
    { 
      id: "04", 
      title: "Creative Direction", 
      description: "Strategic and artistic guidance for your projects to ensure a cohesive and impactful visual identity.",
      icon: <Palette className="w-6 h-6" />
    },
  ];

  return (
    <section id="services" className="py-32 px-6 max-w-7xl mx-auto overflow-hidden">
      <div className="flex flex-col gap-12">
        <div className="w-full opacity-100 pointer-events-none mb-8">
          <div className="flex whitespace-nowrap text-[10vw] font-bold uppercase tracking-tighter leading-none select-none animate-marquee">
            {[...Array(10)].map((_, i) => (
              <span key={i} className="mr-10">services.</span>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service) => (
            <motion.div 
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="group p-10 rounded-[3rem] border border-border hover:bg-secondary-beige/50 transition-all duration-500 flex flex-col gap-6"
            >
              <div className="flex justify-between items-start">
                <div className="w-12 h-12 bg-primary-black text-background rounded-2xl flex items-center justify-center group-hover:bg-accent-gold group-hover:text-primary-black transition-colors duration-500">
                  {service.icon}
                </div>
                <span className="text-sm font-medium text-muted-foreground">{service.id}</span>
              </div>
              <div className="flex flex-col gap-4">
                <h3 className="text-3xl font-bold tracking-tighter italic group-hover:text-accent transition-colors">
                  {service.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {service.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  useEffect(() => {
    emailjs.init("YXlzE_JRetHC0-tyx");
  }, []);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });
  const [isSending, setIsSending] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submission started", formData);
    setIsSending(true);
    setStatus('idle');
    setErrorMessage("");

    try {
      const result = await emailjs.send(
        'service_5xwuzwh',
        'template_e03wpe3',
        {
          from_name: formData.name.trim(),
          from_email: formData.email.trim(),
          message: formData.message.trim(),
          to_name: 'Binit Vinayak',
        },
        'YXlzE_JRetHC0-tyx'
      );
      console.log("EmailJS Success:", result);
      setStatus('success');
      setFormData({ name: '', email: '', message: '' });
      setTimeout(() => setStatus('idle'), 5000);
    } catch (error: any) {
      console.error('EmailJS Error:', error);
      setStatus('error');
      setErrorMessage(error?.text || error?.message || "Something went wrong");
      setTimeout(() => setStatus('idle'), 8000);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <section id="contact" className="py-32 px-6 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
        <div className="flex flex-col gap-8">
          <h2 className="text-6xl font-bold tracking-tighter">Let's create<br />something<br /><span className="text-accent-gold">extraordinary.</span></h2>
          <p className="text-lg text-muted-foreground max-w-md">
            Whether you have a specific project in mind or just want to explore the possibilities of visual storytelling, I'd love to hear from you.
          </p>
          <div className="flex flex-col gap-4 mt-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-secondary-beige rounded-full flex items-center justify-center">
                <Mail className="w-5 h-5 text-accent-gold" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-widest text-muted-foreground font-bold">Email</p>
                <p className="font-medium">binitvinayak6@gmail.com</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-secondary-beige rounded-full flex items-center justify-center">
                <MapPin className="w-5 h-5 text-accent-gold" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-widest text-muted-foreground font-bold">Location</p>
                <p className="font-medium">Uttar pradesh , India</p>
              </div>
            </div>
          </div>
        </div>
        
        <Card className="p-8 border-none bg-secondary-beige/50 shadow-none rounded-[2rem]">
          <form onSubmit={handleSubmit} className="flex flex-col gap-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-xs font-bold uppercase tracking-widest ml-1">Name</label>
                <Input 
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Your name" 
                  className="bg-background border-none rounded-xl h-12" 
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-xs font-bold uppercase tracking-widest ml-1">Email</label>
                <Input 
                  required
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="your@email.com" 
                  className="bg-background border-none rounded-xl h-12" 
                />
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <label className="text-xs font-bold uppercase tracking-widest ml-1">Message</label>
              <Textarea 
                required
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Tell me about your project..." 
                className="bg-background border-none rounded-xl min-h-[150px]" 
              />
            </div>
            <Button 
              type="submit"
              disabled={isSending}
              className="w-full bg-primary-black text-background hover:bg-accent-gold hover:text-primary-black transition-all h-14 rounded-xl font-bold uppercase tracking-widest text-xs"
            >
              {isSending ? "Sending..." : "Send Message"}
            </Button>
            
            {status === 'success' && (
              <p className="text-center text-green-600 font-bold text-sm animate-pulse">
                Message sent successfully!
              </p>
            )}
            {status === 'error' && (
              <p className="text-center text-red-600 font-bold text-sm">
                Failed to send message: {errorMessage}
              </p>
            )}
          </form>
        </Card>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-background pt-32 pb-12 px-6 border-t border-border overflow-hidden">
      <div className="max-w-7xl mx-auto flex flex-col gap-20">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <div className="w-5 h-5 bg-background rounded-full" />
            </div>
          </div>
          <div className="flex gap-12 text-sm font-medium uppercase tracking-widest">
            <a href="#home" className="hover:text-accent transition-colors">Home</a>
            <a href="#about" className="hover:text-accent transition-colors">About</a>
            <a href="#portfolio" className="hover:text-accent transition-colors">Portfolio</a>
            <a href="#services" className="hover:text-accent transition-colors">Services</a>
            <a href="#contact" className="hover:text-accent transition-colors">Contact</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  return (
    <Router>
      <div className="selection:bg-accent-gold selection:text-primary-black">
        <Navbar />
        <Routes>
          <Route path="/" element={
            <main>
              <Hero />
              <About />
              <Portfolio />
              <Services />
              <Contact />
            </main>
          } />
          <Route path="/portfolio" element={<PortfolioPage />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}
